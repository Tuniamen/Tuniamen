@echo off
setlocal EnableDelayedExpansion

REM ============================================================================
REM AMENO ASSISTANT - GESTIONNAIRE CONTINU 24/7 (BOT TELEGRAM ET DASHBOARD)
REM ============================================================================

if "%1"=="--worker-bot" goto worker_bot
if "%1"=="--worker-dashboard" goto worker_dashboard
if "%1"=="--stop" goto stop_services

title Ameno Control Center - Gestionnaire Principal
cd /d "%~dp0"

:main_menu
cls
echo ================================================================================
echo           AMENO ASSISTANT - TOUR DE CONTROLE ET BOT TELEGRAM [24/7]
echo ================================================================================
echo.

REM 1. Verification de Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR CRITIQUE] Python n'est pas detecte dans votre variable PATH.
    echo Veuillez installer Python 3.10+ et cocher "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

REM 2. Verification du fichier .env
if not exist ".env" (
    echo [ATTENTION] Le fichier .env est introuvable dans le dossier.
    echo Assurez-vous d'avoir configure TELEGRAM_TOKEN et OPENROUTER_API_KEY.
    echo.
)

REM 3. Verification des dependances requises
python -c "import flask, requests, telegram, docx, openai, dotenv" >nul 2>&1
if %errorlevel% neq 0 (
    echo [*] Premier lancement detecte ou dependances manquantes...
    echo [*] Installation automatique des bibliotheques via requirements.txt...
    pip install -r requirements.txt
    if !errorlevel! neq 0 (
        echo [ERREUR] Impossible d'installer automatiquement les dependances.
        echo Verifiez votre connexion Internet ou executez installer_dependances.bat.
        pause
        exit /b 1
    )
    echo [OK] Dependances installees avec succes.
)

REM 4. Nettoyage des anciennes instances eventuelles
echo [*] Initialisation et verification des processus...
call :cleanup_old_instances

REM 4. Lancement du Bot Telegram en mode continu
echo [*] Lancement du Bot Telegram en arriere-plan continu...
start "Ameno - Bot Telegram" cmd /c ""%~f0" --worker-bot"

REM 5. Lancement du Dashboard en mode continu
echo [*] Lancement du Dashboard en arriere-plan continu...
start "Ameno - Dashboard" cmd /c ""%~f0" --worker-dashboard"

REM 6. Pause pour permettre l'initialisation
echo [*] Demarrage des services en cours...
timeout /t 3 /nobreak >nul

REM 7. Ouverture du navigateur
start http://localhost:5000

:status_loop
cls
echo ================================================================================
echo           AMENO ASSISTANT - TOUS LES SERVICES SONT EN LIGNE [24/7]
echo ================================================================================
echo.
echo  [OK] Bot Telegram        : ACTIF - En ecoute permanente sur Telegram
echo  [OK] Tour de Controle    : ACTIF - Serveur Web Flask en ecoute
echo  [OK] URL Locale          : http://localhost:5000
echo  [OK] URL Reseau          : http://127.0.0.1:5000
echo  [OK] Auto-Restart        : ACTIF - Relance automatique en cas de panne
echo.
echo ================================================================================
echo  COMMANDES DISPONIBLES :
echo    [O] Ouvrir la Tour de Controle dans le navigateur
echo    [R] Redemarrer tous les services
echo    [Q] Arreter completement tous les services et quitter
echo ================================================================================
echo.

choice /c ORQ /n /m "Entrez votre choix [O, R, ou Q] : "
if errorlevel 3 goto quit_app
if errorlevel 2 goto restart_services
if errorlevel 1 goto open_browser

:open_browser
start http://localhost:5000
goto status_loop

:restart_services
echo.
echo [*] Redemarrage en cours de tous les services Ameno...
call :cleanup_old_instances
timeout /t 2 /nobreak >nul
goto main_menu

:quit_app
echo.
echo [*] Arret propre de tous les services Ameno en cours...
call :cleanup_old_instances
echo [OK] Tous les services ont ete arretes.
timeout /t 2 /nobreak >nul
exit /b 0

REM ============================================================================
REM ROUTINE WORKER : BOT TELEGRAM
REM ============================================================================
:worker_bot
title Ameno - Bot Telegram
cd /d "%~dp0"
:bot_loop
cls
echo ================================================================================
echo                  AMENO - SERVICE BOT TELEGRAM ACTIF
echo ================================================================================
echo [INFO] Demarrage du bot Telegram...
echo [INFO] Gestion centralisee par la fenetre Ameno Control Center.
echo --------------------------------------------------------------------------------
echo.
python bot_telegram.py
echo.
echo --------------------------------------------------------------------------------
echo [ATTENTION] Le processus s'est arrete.
echo [AUTO-RESTART] Redemarrage automatique dans 5 secondes...
echo --------------------------------------------------------------------------------
timeout /t 5 /nobreak >nul
goto bot_loop

REM ============================================================================
REM ROUTINE WORKER : DASHBOARD CONTROL TOWER
REM ============================================================================
:worker_dashboard
title Ameno - Dashboard
cd /d "%~dp0"
:dash_loop
cls
echo ================================================================================
echo               AMENO - TOUR DE CONTROLE DASHBOARD ACTIF
echo ================================================================================
echo [INFO] Demarrage du serveur Dashboard sur http://localhost:5000...
echo [INFO] Gestion centralisee par la fenetre Ameno Control Center.
echo --------------------------------------------------------------------------------
echo.
python dashboard.py
echo.
echo --------------------------------------------------------------------------------
echo [ATTENTION] Le serveur Dashboard s'est arrete.
echo [AUTO-RESTART] Redemarrage automatique dans 5 secondes...
echo --------------------------------------------------------------------------------
timeout /t 5 /nobreak >nul
goto dash_loop

REM ============================================================================
REM ROUTINE DE NETTOYAGE / ARRET
REM ============================================================================
:cleanup_old_instances
taskkill /F /T /FI "WINDOWTITLE eq Ameno - Bot Telegram*" >nul 2>&1
taskkill /F /T /FI "WINDOWTITLE eq Ameno - Dashboard*" >nul 2>&1

powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }" >nul 2>&1
exit /b 0

:stop_services
echo [*] Arret de tous les services Ameno en cours...
call :cleanup_old_instances
echo [OK] Tous les services Ameno ont ete arretes.
exit /b 0
