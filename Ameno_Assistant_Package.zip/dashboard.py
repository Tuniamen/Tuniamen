# ==============================================================================
# FICHIER : dashboard.py
# TOUR DE CONTRÔLE v2 — NŒUDS DRAGGABLES, MÉTRIQUES ENRICHIES, DESIGN PREMIUM
# ==============================================================================
import sqlite3
import requests
import json
import time
import threading
import os
from flask import Flask, jsonify, request, render_template_string
from config import TELEGRAM_TOKEN, OPENROUTER_API_KEY, DB_PATH, FREE_MODELS_POOL, DOCS_DIR
from agent_expert import AgentAchats

app = Flask(__name__)
agent = AgentAchats()

# Horodatage de démarrage pour l'uptime
SERVER_START_TIME = time.time()

# ==============================================================================
# TEMPLATE HTML — AMENO CONTROL TOWER v2
# ==============================================================================
HTML_VIEW = r"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ameno Control Tower — Live Orchestration Studio</title>
    <meta name="description" content="Tour de contrôle en temps réel pour l'orchestration de l'Agent Achats Ameno.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* ===== RESET & BASE ===== */
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --bg-deep: #080b14;
            --bg-surface: #0d1121;
            --bg-card: rgba(16, 20, 38, 0.85);
            --bg-card-solid: #101426;
            --bg-elevated: rgba(22, 28, 52, 0.9);
            --border-subtle: rgba(56, 68, 114, 0.35);
            --border-medium: rgba(72, 88, 140, 0.4);
            --border-glow-blue: rgba(59, 130, 246, 0.6);
            --border-glow-green: rgba(16, 185, 129, 0.5);
            --border-glow-red: rgba(239, 68, 68, 0.5);
            --text-primary: #e8ecf4;
            --text-secondary: #8892b0;
            --text-muted: #5a6380;
            --accent-blue: #3b82f6;
            --accent-cyan: #06b6d4;
            --accent-green: #10b981;
            --accent-amber: #f59e0b;
            --accent-purple: #8b5cf6;
            --accent-red: #ef4444;
            --accent-rose: #f43f5e;
            --glass-bg: rgba(16, 20, 38, 0.65);
            --glass-border: rgba(72, 88, 140, 0.25);
            --glass-blur: 16px;
            --radius-sm: 6px;
            --radius-md: 10px;
            --radius-lg: 14px;
            --radius-xl: 18px;
            --shadow-card: 0 8px 32px rgba(0,0,0,0.4), 0 2px 8px rgba(0,0,0,0.3);
            --shadow-glow-blue: 0 0 24px rgba(59, 130, 246, 0.3), 0 0 48px rgba(59, 130, 246, 0.1);
            --shadow-glow-green: 0 0 24px rgba(16, 185, 129, 0.3);
            --shadow-glow-red: 0 0 24px rgba(239, 68, 68, 0.3);
            --transition-fast: 0.15s ease;
            --transition-normal: 0.25s ease;
            --transition-smooth: 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-deep);
            color: var(--text-primary);
            height: 100vh;
            overflow: hidden;
            user-select: none;
            -webkit-font-smoothing: antialiased;
        }
        /* ===== GRID BACKGROUND ===== */
        body::before {
            content: '';
            position: fixed; inset: 0; z-index: 0;
            background-image:
                radial-gradient(circle at 1px 1px, rgba(56, 68, 114, 0.18) 1px, transparent 0);
            background-size: 28px 28px;
            pointer-events: none;
        }
        body::after {
            content: '';
            position: fixed; inset: 0; z-index: 0;
            background: radial-gradient(ellipse 80% 60% at 50% 0%, rgba(59, 130, 246, 0.04) 0%, transparent 60%),
                        radial-gradient(ellipse 60% 40% at 80% 100%, rgba(139, 92, 246, 0.03) 0%, transparent 50%);
            pointer-events: none;
        }

        /* ===== LAYOUT ===== */
        .app-layout {
            display: flex; flex-direction: column;
            height: 100vh; position: relative; z-index: 1;
        }

        /* ===== HEADER ===== */
        .header {
            height: 56px;
            background: var(--glass-bg);
            backdrop-filter: blur(var(--glass-blur));
            -webkit-backdrop-filter: blur(var(--glass-blur));
            border-bottom: 1px solid var(--glass-border);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 20px;
            flex-shrink: 0; z-index: 30;
        }
        .header-left { display: flex; align-items: center; gap: 14px; }
        .header-right { display: flex; align-items: center; gap: 10px; }
        .logo-group { display: flex; align-items: center; gap: 10px; }
        .logo-dot {
            width: 10px; height: 10px; border-radius: 50%;
            background: var(--accent-green);
            box-shadow: 0 0 8px var(--accent-green);
            animation: pulse-dot 2s ease-in-out infinite;
        }
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; box-shadow: 0 0 8px var(--accent-green); }
            50% { opacity: 0.6; box-shadow: 0 0 16px var(--accent-green), 0 0 32px rgba(16, 185, 129, 0.2); }
        }
        .logo-text {
            font-weight: 800; font-size: 13px;
            letter-spacing: 1.8px; color: var(--text-primary);
        }
        .logo-divider {
            width: 1px; height: 20px;
            background: var(--border-subtle);
        }
        .logo-sub {
            font-size: 11px; color: var(--text-muted);
            font-weight: 400; letter-spacing: 0.3px;
        }
        .status-pill {
            display: flex; align-items: center; gap: 6px;
            padding: 5px 12px; border-radius: 20px;
            font-size: 11px; font-weight: 600;
            font-family: 'JetBrains Mono', monospace;
            transition: var(--transition-normal);
        }
        .pill-ok {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #6ee7b7;
        }
        .pill-err {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }
        .pill-loading {
            background: rgba(100, 116, 139, 0.15);
            border: 1px solid rgba(100, 116, 139, 0.25);
            color: var(--text-muted);
        }
        .pill-dot {
            width: 6px; height: 6px; border-radius: 50%;
        }
        .pill-dot-ok { background: var(--accent-green); }
        .pill-dot-err { background: var(--accent-red); }
        .pill-dot-loading { background: var(--text-muted); }
        .header-clock {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; color: var(--text-muted);
            letter-spacing: 0.5px;
        }
        .header-btn {
            display: flex; align-items: center; gap: 6px;
            padding: 7px 16px; border-radius: var(--radius-md);
            font-size: 11px; font-weight: 700;
            border: none; cursor: pointer;
            transition: var(--transition-fast);
            letter-spacing: 0.3px;
        }
        .header-btn:active { transform: scale(0.96); }
        .btn-amber {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: #1a1a1a;
            box-shadow: 0 2px 12px rgba(245, 158, 11, 0.3);
        }
        .btn-amber:hover { box-shadow: 0 4px 20px rgba(245, 158, 11, 0.45); }
        .btn-config {
            background: var(--bg-elevated);
            border: 1px solid var(--border-subtle);
            color: var(--text-secondary);
        }
        .btn-config:hover { border-color: var(--border-medium); color: var(--text-primary); }
        .btn-reset {
            background: var(--bg-elevated);
            border: 1px solid var(--border-subtle);
            color: var(--text-secondary);
        }
        .btn-reset:hover { border-color: var(--accent-cyan); color: var(--accent-cyan); }

        /* ===== STATS BAR ===== */
        .stats-bar {
            display: flex; align-items: stretch; gap: 1px;
            background: var(--border-subtle);
            border-bottom: 1px solid var(--glass-border);
            flex-shrink: 0; z-index: 20;
        }
        .stat-cell {
            flex: 1;
            background: var(--bg-surface);
            padding: 10px 16px;
            display: flex; flex-direction: column; gap: 2px;
            transition: var(--transition-fast);
        }
        .stat-cell:hover { background: rgba(22, 28, 52, 0.9); }
        .stat-label {
            font-size: 9px; font-weight: 600;
            text-transform: uppercase; letter-spacing: 1.2px;
            color: var(--text-muted);
        }
        .stat-value {
            font-family: 'JetBrains Mono', monospace;
            font-size: 16px; font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
        }
        .stat-value.green { color: var(--accent-green); }
        .stat-value.blue { color: var(--accent-blue); }
        .stat-value.amber { color: var(--accent-amber); }
        .stat-value.purple { color: var(--accent-purple); }
        .stat-value.cyan { color: var(--accent-cyan); }

        /* ===== MAIN AREA ===== */
        .main-area {
            flex: 1; display: flex; overflow: hidden;
            position: relative;
        }

        /* ===== CANVAS ===== */
        .canvas {
            flex: 1; position: relative; overflow: hidden;
        }
        .canvas-svg {
            position: absolute; inset: 0;
            width: 100%; height: 100%;
            pointer-events: none; z-index: 1;
        }

        /* ===== NODE CARDS ===== */
        .node {
            position: absolute; z-index: 10;
            width: 280px;
            background: var(--bg-card);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1.5px solid var(--border-subtle);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-card);
            cursor: grab;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .node:hover {
            border-color: var(--border-medium);
        }
        .node.dragging {
            cursor: grabbing;
            z-index: 100;
            box-shadow: var(--shadow-card), 0 16px 48px rgba(0,0,0,0.5);
        }
        .node.state-active {
            border-color: var(--border-glow-blue) !important;
            box-shadow: var(--shadow-glow-blue), var(--shadow-card) !important;
        }
        .node.state-success {
            border-color: var(--border-glow-green) !important;
            box-shadow: var(--shadow-glow-green), var(--shadow-card) !important;
        }
        .node.state-error {
            border-color: var(--border-glow-red) !important;
            box-shadow: var(--shadow-glow-red), var(--shadow-card) !important;
        }
        .node-header {
            padding: 12px 16px 0;
            display: flex; justify-content: space-between; align-items: center;
        }
        .node-tag {
            font-size: 9px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1.5px;
        }
        .tag-trigger { color: var(--accent-amber); }
        .tag-knowledge { color: var(--accent-green); }
        .tag-llm { color: var(--accent-purple); }
        .tag-dispatch { color: var(--accent-cyan); }
        .node-dot {
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--text-muted);
            transition: var(--transition-normal);
        }
        .node-dot.dot-active {
            background: var(--accent-amber);
            animation: ping-dot 1.2s ease-in-out infinite;
        }
        .node-dot.dot-success { background: var(--accent-green); }
        .node-dot.dot-error { background: var(--accent-red); }
        @keyframes ping-dot {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.8); }
        }
        .node-body {
            padding: 10px 16px;
        }
        .node-title-row {
            display: flex; align-items: center; gap: 10px;
            margin-bottom: 8px;
        }
        .node-icon {
            width: 36px; height: 36px;
            display: flex; align-items: center; justify-content: center;
            border-radius: var(--radius-md);
            font-size: 12px; font-weight: 900;
            flex-shrink: 0;
            font-family: 'JetBrains Mono', monospace;
        }
        .icon-tg { background: rgba(59, 130, 246, 0.15); color: var(--accent-blue); }
        .icon-doc { background: rgba(16, 185, 129, 0.15); color: var(--accent-green); }
        .icon-llm { background: rgba(139, 92, 246, 0.15); color: var(--accent-purple); }
        .icon-out { background: rgba(6, 182, 212, 0.15); color: var(--accent-cyan); }
        .node-title {
            font-size: 13px; font-weight: 700;
            color: var(--text-primary);
            line-height: 1.2;
        }
        .node-subtitle {
            font-size: 10px; color: var(--text-muted);
            margin-top: 1px;
        }
        .node-data {
            background: rgba(0, 0, 0, 0.25);
            border-radius: var(--radius-sm);
            padding: 8px 10px;
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
        }
        .node-data-row {
            display: flex; justify-content: space-between;
            padding: 2px 0;
        }
        .node-data-label { color: var(--text-muted); }
        .node-data-value { color: var(--text-secondary); font-weight: 500; }
        .node-data-value.highlight-green { color: #6ee7b7; font-weight: 600; }
        .node-data-value.highlight-purple { color: #c4b5fd; font-weight: 600; }
        .node-data-value.highlight-blue { color: #93c5fd; font-weight: 600; }
        .node-data-value.highlight-amber { color: #fcd34d; font-weight: 600; }
        .node-data-value.highlight-cyan { color: #67e8f9; font-weight: 600; }

        /* ===== PORTS ===== */
        .port {
            width: 12px; height: 12px; border-radius: 50%;
            position: absolute; top: 50%;
            transform: translateY(-50%);
            border: 2px solid rgba(255,255,255,0.7);
            z-index: 15;
            transition: var(--transition-fast);
        }
        .port:hover { transform: translateY(-50%) scale(1.3); }
        .port-out { right: -6px; background: var(--accent-green); }
        .port-in { left: -6px; background: var(--accent-amber); }

        /* ===== SVG WIRES ===== */
        .wire-path {
            fill: none;
            stroke: rgba(56, 68, 114, 0.5);
            stroke-width: 2.5;
            transition: stroke 0.4s ease;
        }
        @keyframes flow-dash {
            to { stroke-dashoffset: -32; }
        }
        .wire-animated {
            stroke: var(--accent-amber) !important;
            stroke-width: 3;
            stroke-dasharray: 8, 5;
            animation: flow-dash 0.8s linear infinite;
            filter: drop-shadow(0 0 4px rgba(245, 158, 11, 0.3));
        }
        .wire-success {
            stroke: var(--accent-green) !important;
            stroke-width: 2.5;
            filter: drop-shadow(0 0 3px rgba(16, 185, 129, 0.2));
        }
        .wire-error {
            stroke: var(--accent-red) !important;
            stroke-width: 2.5;
            filter: drop-shadow(0 0 3px rgba(239, 68, 68, 0.2));
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width: 380px;
            background: var(--bg-surface);
            border-left: 1px solid var(--glass-border);
            display: flex; flex-direction: column;
            flex-shrink: 0; z-index: 20;
        }
        .sidebar-header {
            padding: 12px 16px;
            border-bottom: 1px solid var(--glass-border);
            display: flex; flex-direction: column; gap: 8px;
        }
        .sidebar-title-row {
            display: flex; justify-content: space-between; align-items: center;
        }
        .sidebar-title {
            font-size: 11px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1.2px;
            color: var(--text-secondary);
        }
        .sidebar-badge {
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px; font-weight: 600;
            padding: 3px 8px; border-radius: 10px;
            background: rgba(59, 130, 246, 0.12);
            color: var(--accent-blue);
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        .sidebar-controls {
            display: flex; gap: 6px;
        }
        .filter-btn {
            padding: 4px 10px; border-radius: var(--radius-sm);
            font-size: 10px; font-weight: 600;
            background: transparent;
            border: 1px solid var(--border-subtle);
            color: var(--text-muted);
            cursor: pointer;
            transition: var(--transition-fast);
        }
        .filter-btn:hover { border-color: var(--border-medium); color: var(--text-secondary); }
        .filter-btn.active {
            background: rgba(59, 130, 246, 0.12);
            border-color: rgba(59, 130, 246, 0.3);
            color: var(--accent-blue);
        }
        .search-input {
            flex: 1;
            background: rgba(0,0,0,0.2);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-sm);
            padding: 4px 10px;
            font-size: 11px; font-family: 'Inter', sans-serif;
            color: var(--text-primary);
            outline: none;
            transition: var(--transition-fast);
        }
        .search-input::placeholder { color: var(--text-muted); }
        .search-input:focus { border-color: var(--accent-blue); }
        .log-list {
            flex: 1; overflow-y: auto;
            padding: 8px;
            display: flex; flex-direction: column; gap: 6px;
        }
        .log-list::-webkit-scrollbar { width: 4px; }
        .log-list::-webkit-scrollbar-track { background: transparent; }
        .log-list::-webkit-scrollbar-thumb { background: var(--border-subtle); border-radius: 4px; }
        .log-card {
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 10px 12px;
            cursor: pointer;
            transition: var(--transition-fast);
        }
        .log-card:hover {
            border-color: var(--border-medium);
            background: rgba(22, 28, 52, 0.6);
        }
        .log-card.log-error {
            background: rgba(239, 68, 68, 0.05);
            border-color: rgba(239, 68, 68, 0.2);
        }
        .log-card.expanded .log-response { display: block; }
        .log-meta {
            display: flex; justify-content: space-between;
            font-family: 'JetBrains Mono', monospace;
            font-size: 9px; color: var(--text-muted);
            margin-bottom: 4px;
        }
        .log-status-ok { color: var(--accent-green); font-weight: 700; }
        .log-status-err { color: var(--accent-red); font-weight: 700; }
        .log-question {
            font-size: 12px; font-weight: 600;
            color: var(--text-primary);
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            margin-bottom: 4px;
        }
        .log-footer {
            display: flex; justify-content: space-between;
            font-family: 'JetBrains Mono', monospace;
            font-size: 9px; color: var(--text-muted);
        }
        .log-response {
            display: none;
            margin-top: 8px; padding-top: 8px;
            border-top: 1px solid var(--border-subtle);
            font-size: 11px; color: var(--text-secondary);
            line-height: 1.5;
            max-height: 180px; overflow-y: auto;
            white-space: pre-wrap; word-break: break-word;
        }

        /* ===== CANVAS ERROR BANNER ===== */
        .canvas-error {
            position: absolute; bottom: 16px; left: 16px; right: 16px;
            background: rgba(127, 29, 29, 0.85);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(239, 68, 68, 0.4);
            border-radius: var(--radius-md);
            padding: 10px 16px;
            display: none; align-items: center; justify-content: space-between;
            z-index: 25;
            font-size: 12px; color: #fca5a5;
        }
        .canvas-error.visible { display: flex; }
        .canvas-error-close {
            background: none; border: none; color: #fca5a5;
            font-size: 18px; cursor: pointer; padding: 0 4px;
        }

        /* ===== MODAL OVERLAY ===== */
        .modal-overlay {
            position: fixed; inset: 0;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(6px);
            display: none; align-items: center; justify-content: center;
            z-index: 200;
        }
        .modal-overlay.visible { display: flex; }
        .modal {
            background: var(--bg-card-solid);
            border: 1px solid var(--border-medium);
            border-radius: var(--radius-xl);
            box-shadow: 0 24px 80px rgba(0,0,0,0.6);
            width: 560px; max-height: 85vh;
            display: flex; flex-direction: column;
            animation: modal-in 0.25s ease;
        }
        @keyframes modal-in {
            from { opacity: 0; transform: translateY(16px) scale(0.97); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }
        .modal-header {
            padding: 20px 24px 16px;
            display: flex; justify-content: space-between; align-items: center;
            border-bottom: 1px solid var(--border-subtle);
        }
        .modal-title {
            font-size: 14px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px;
            color: var(--accent-amber);
        }
        .modal-close {
            background: none; border: none;
            color: var(--text-muted); font-size: 22px;
            cursor: pointer; padding: 0;
            transition: var(--transition-fast);
        }
        .modal-close:hover { color: var(--text-primary); }
        .modal-body {
            padding: 20px 24px; overflow-y: auto;
            display: flex; flex-direction: column; gap: 16px;
        }
        .form-group { display: flex; flex-direction: column; gap: 5px; }
        .form-label {
            font-size: 11px; font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase; letter-spacing: 0.8px;
        }
        .form-input, .form-select {
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-sm);
            padding: 10px 12px;
            font-size: 13px; font-family: 'Inter', sans-serif;
            color: var(--text-primary);
            outline: none;
            transition: var(--transition-fast);
        }
        .form-input:focus, .form-select:focus { border-color: var(--accent-amber); }
        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%235a6380' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 36px;
        }
        .form-row { display: flex; gap: 12px; }
        .form-row .form-group { flex: 1; }
        .modal-footer {
            padding: 16px 24px 20px;
            display: flex; justify-content: flex-end; gap: 10px;
            border-top: 1px solid var(--border-subtle);
        }
        .modal-btn {
            padding: 9px 20px; border-radius: var(--radius-md);
            font-size: 12px; font-weight: 700;
            border: none; cursor: pointer;
            transition: var(--transition-fast);
            letter-spacing: 0.3px;
        }
        .modal-btn:active { transform: scale(0.96); }
        .modal-btn-secondary {
            background: var(--bg-elevated);
            border: 1px solid var(--border-subtle);
            color: var(--text-secondary);
        }
        .modal-btn-primary {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: #1a1a1a;
            box-shadow: 0 2px 12px rgba(245, 158, 11, 0.3);
        }
        .modal-btn-primary:hover { box-shadow: 0 4px 20px rgba(245, 158, 11, 0.45); }

        /* Response area in modal */
        .response-area {
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 14px 16px;
            font-size: 12px; line-height: 1.6;
            color: var(--text-secondary);
            max-height: 260px; overflow-y: auto;
            white-space: pre-wrap; word-break: break-word;
            display: none;
        }
        .response-area.visible { display: block; }
        .response-area .resp-meta {
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px; color: var(--text-muted);
            margin-bottom: 8px; padding-bottom: 8px;
            border-bottom: 1px solid var(--border-subtle);
        }

        /* ===== CONFIG MODAL ===== */
        .config-section {
            background: rgba(0,0,0,0.2);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            padding: 14px 16px;
        }
        .config-section-title {
            font-size: 10px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1.2px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }
        .config-row {
            display: flex; justify-content: space-between; align-items: center;
            padding: 5px 0;
            font-size: 12px;
        }
        .config-key { color: var(--text-muted); }
        .config-val {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; color: var(--text-secondary);
            text-align: right; max-width: 280px;
            white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .config-val.ok { color: var(--accent-green); }
        .config-val.err { color: var(--accent-red); }
        .model-chip {
            display: inline-block;
            padding: 3px 8px; margin: 2px 3px;
            background: rgba(139, 92, 246, 0.1);
            border: 1px solid rgba(139, 92, 246, 0.25);
            border-radius: var(--radius-sm);
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px; color: #c4b5fd;
        }

        /* ===== HISTORY MODAL ===== */
        .history-modal {
            width: 95vw; max-width: 1400px;
            max-height: 90vh;
        }
        .history-toolbar {
            display: flex; align-items: center; gap: 10px;
            flex-wrap: wrap;
        }
        .history-search {
            flex: 1; min-width: 200px;
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-sm);
            padding: 8px 12px;
            font-size: 12px; font-family: 'Inter', sans-serif;
            color: var(--text-primary);
            outline: none;
            transition: var(--transition-fast);
        }
        .history-search::placeholder { color: var(--text-muted); }
        .history-search:focus { border-color: var(--accent-blue); }
        .history-count {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; color: var(--text-muted);
            white-space: nowrap;
        }
        .history-table-wrap {
            overflow: auto; flex: 1;
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
        }
        .history-table-wrap::-webkit-scrollbar { width: 6px; height: 6px; }
        .history-table-wrap::-webkit-scrollbar-track { background: transparent; }
        .history-table-wrap::-webkit-scrollbar-thumb { background: var(--border-subtle); border-radius: 4px; }
        .history-table {
            width: 100%; border-collapse: collapse;
            font-size: 12px;
        }
        .history-table thead {
            position: sticky; top: 0; z-index: 2;
        }
        .history-table th {
            background: rgba(22, 28, 52, 0.95);
            backdrop-filter: blur(8px);
            padding: 10px 12px;
            text-align: left;
            font-size: 10px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px;
            color: var(--text-muted);
            border-bottom: 1px solid var(--border-medium);
            cursor: pointer;
            user-select: none;
            white-space: nowrap;
            transition: var(--transition-fast);
        }
        .history-table th:hover { color: var(--text-secondary); }
        .history-table th.sorted { color: var(--accent-blue); }
        .history-table th .sort-arrow { margin-left: 4px; font-size: 9px; }
        .history-table td {
            padding: 9px 12px;
            border-bottom: 1px solid rgba(56, 68, 114, 0.15);
            color: var(--text-secondary);
            vertical-align: top;
        }
        .history-table tbody tr {
            transition: var(--transition-fast);
        }
        .history-table tbody tr:hover {
            background: rgba(59, 130, 246, 0.04);
        }
        .history-table .col-id {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; color: var(--text-muted);
            width: 50px;
        }
        .history-table .col-time {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; white-space: nowrap;
        }
        .history-table .col-user {
            max-width: 120px; overflow: hidden;
            text-overflow: ellipsis; white-space: nowrap;
        }
        .history-table .col-question {
            max-width: 250px; overflow: hidden;
            text-overflow: ellipsis; white-space: nowrap;
            font-weight: 500; color: var(--text-primary);
        }
        .history-table .col-response {
            max-width: 300px; overflow: hidden;
            text-overflow: ellipsis; white-space: nowrap;
            font-size: 11px;
        }
        .history-table .col-model {
            font-family: 'JetBrains Mono', monospace;
            font-size: 10px; max-width: 140px;
            overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }
        .history-table .col-tokens {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; white-space: nowrap;
        }
        .history-table .col-latency {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; white-space: nowrap;
        }
        .history-table .col-status { white-space: nowrap; }
        .status-badge {
            display: inline-block;
            padding: 3px 8px; border-radius: 10px;
            font-size: 10px; font-weight: 700;
            letter-spacing: 0.3px;
        }
        .status-badge.ok {
            background: rgba(16, 185, 129, 0.12);
            color: #6ee7b7;
            border: 1px solid rgba(16, 185, 129, 0.25);
        }
        .status-badge.err {
            background: rgba(239, 68, 68, 0.12);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.25);
        }
        .history-pagination {
            display: flex; align-items: center; justify-content: center; gap: 6px;
            padding-top: 8px;
        }
        .page-btn {
            padding: 5px 12px; border-radius: var(--radius-sm);
            font-size: 11px; font-weight: 600;
            background: var(--bg-elevated);
            border: 1px solid var(--border-subtle);
            color: var(--text-secondary);
            cursor: pointer;
            transition: var(--transition-fast);
        }
        .page-btn:hover { border-color: var(--border-medium); }
        .page-btn.active {
            background: rgba(59, 130, 246, 0.15);
            border-color: rgba(59, 130, 246, 0.4);
            color: var(--accent-blue);
        }
        .page-btn:disabled { opacity: 0.3; cursor: default; }
        .page-info {
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px; color: var(--text-muted);
            padding: 0 8px;
        }

        /* Row detail expansion */
        .history-table .detail-row td {
            padding: 0;
            border-bottom: 1px solid rgba(56, 68, 114, 0.25);
        }
        .detail-content {
            padding: 12px 16px;
            background: rgba(0,0,0,0.2);
            display: flex; gap: 20px;
        }
        .detail-col {
            flex: 1; min-width: 0;
        }
        .detail-label {
            font-size: 9px; font-weight: 700;
            text-transform: uppercase; letter-spacing: 1px;
            color: var(--text-muted); margin-bottom: 4px;
        }
        .detail-text {
            font-size: 12px; line-height: 1.5;
            color: var(--text-secondary);
            white-space: pre-wrap; word-break: break-word;
            max-height: 200px; overflow-y: auto;
        }

        /* History button style */
        .btn-history {
            background: rgba(6, 182, 212, 0.12);
            border: 1px solid rgba(6, 182, 212, 0.3);
            color: var(--accent-cyan);
        }
        .btn-history:hover {
            background: rgba(6, 182, 212, 0.2);
            border-color: rgba(6, 182, 212, 0.5);
        }
        .btn-delete-row {
            background: transparent;
            border: 1px solid transparent;
            color: var(--text-muted);
            border-radius: 4px;
            padding: 3px 7px;
            cursor: pointer;
            font-size: 13px;
            line-height: 1;
            transition: var(--transition-fast);
        }
        .btn-delete-row:hover {
            color: #ef4444;
            background: rgba(239, 68, 68, 0.15);
            border-color: rgba(239, 68, 68, 0.3);
            transform: scale(1.1);
        }
        .btn-delete-full {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition-fast);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 10px;
        }
        .btn-delete-full:hover {
            background: rgba(239, 68, 68, 0.25);
            border-color: #ef4444;
            color: #fff;
        }
        .history-alert {
            display: none;
            font-size: 11px;
            color: #6ee7b7;
            background: rgba(16, 185, 129, 0.12);
            border: 1px solid rgba(16, 185, 129, 0.25);
            border-radius: var(--radius-sm);
            padding: 4px 10px;
        }
    </style>
</head>
<body>
<div class="app-layout">

    <!-- ===== HEADER ===== -->
    <header class="header">
        <div class="header-left">
            <div class="logo-group">
                <div class="logo-dot" id="global-dot"></div>
                <span class="logo-text">AMENO CONTROL TOWER</span>
                <div class="logo-divider"></div>
                <span class="logo-sub">Orchestration & Audit — <span id="uptime-display">0m</span></span>
            </div>
            <div id="tg-pill" class="status-pill pill-loading">
                <span class="pill-dot pill-dot-loading"></span> Telegram…
            </div>
            <div id="or-pill" class="status-pill pill-loading">
                <span class="pill-dot pill-dot-loading"></span> OpenRouter…
            </div>
        </div>
        <div class="header-right">
            <span class="header-clock" id="live-clock">--:--:--</span>
            <button class="header-btn btn-reset" onclick="resetLayout()" title="Réinitialiser la position des nœuds">↺ Reset</button>
            <button class="header-btn btn-history" onclick="openHistory()">📋 Historique</button>
            <button class="header-btn btn-config" onclick="openModal('configModal')">⚙ Config</button>
            <button class="header-btn btn-amber" onclick="openModal('testModal')">⚡ Test Pipeline</button>
        </div>
    </header>

    <!-- ===== STATS BAR ===== -->
    <div class="stats-bar">
        <div class="stat-cell">
            <span class="stat-label">Total Requêtes</span>
            <span class="stat-value blue" id="stat-total">—</span>
        </div>
        <div class="stat-cell">
            <span class="stat-label">Taux de Succès</span>
            <span class="stat-value green" id="stat-success">—</span>
        </div>
        <div class="stat-cell">
            <span class="stat-label">Latence Moyenne</span>
            <span class="stat-value amber" id="stat-latency">—</span>
        </div>
        <div class="stat-cell">
            <span class="stat-label">Tokens Cumulés</span>
            <span class="stat-value purple" id="stat-tokens">—</span>
        </div>
        <div class="stat-cell">
            <span class="stat-label">Modèle Top</span>
            <span class="stat-value cyan" id="stat-model">—</span>
        </div>
        <div class="stat-cell">
            <span class="stat-label">Dernière Activité</span>
            <span class="stat-value" id="stat-last" style="font-size:12px;">—</span>
        </div>
    </div>

    <!-- ===== MAIN AREA ===== -->
    <div class="main-area">

        <!-- CANVAS -->
        <div class="canvas" id="canvas">

            <!-- SVG WIRES LAYER -->
            <svg class="canvas-svg" id="svg-layer">
                <defs>
                    <filter id="wire-glow">
                        <feGaussianBlur stdDeviation="2" result="blur"/>
                        <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
                    </filter>
                </defs>
                <path id="wire1" class="wire-path" d="M 0 0"/>
                <path id="wire2" class="wire-path" d="M 0 0"/>
                <path id="wire3" class="wire-path" d="M 0 0"/>
            </svg>

            <!-- NODE 1: TELEGRAM INGEST -->
            <div class="node" id="node1" data-default-x="40" data-default-y="60">
                <div class="port port-out" id="p1-out"></div>
                <div class="node-header">
                    <span class="node-tag tag-trigger">① Trigger</span>
                    <span class="node-dot" id="dot1"></span>
                </div>
                <div class="node-body">
                    <div class="node-title-row">
                        <div class="node-icon icon-tg">TG</div>
                        <div>
                            <div class="node-title">Telegram Ingest</div>
                            <div class="node-subtitle">Écoute des acheteurs</div>
                        </div>
                    </div>
                    <div class="node-data">
                        <div class="node-data-row">
                            <span class="node-data-label">Expéditeur</span>
                            <span class="node-data-value" id="n1-user">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Message</span>
                            <span class="node-data-value highlight-blue" id="n1-msg" style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Reçu à</span>
                            <span class="node-data-value" id="n1-time">—</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- NODE 2: KNOWLEDGE BASE -->
            <div class="node" id="node2" data-default-x="420" data-default-y="40">
                <div class="port port-in" id="p2-in"></div>
                <div class="port port-out" id="p2-out"></div>
                <div class="node-header">
                    <span class="node-tag tag-knowledge">② Knowledge Base</span>
                    <span class="node-dot" id="dot2"></span>
                </div>
                <div class="node-body">
                    <div class="node-title-row">
                        <div class="node-icon icon-doc">DOC</div>
                        <div>
                            <div class="node-title">Procédures Word</div>
                            <div class="node-subtitle">Manuel complet en RAM</div>
                        </div>
                    </div>
                    <div class="node-data">
                        <div class="node-data-row">
                            <span class="node-data-label">Volume</span>
                            <span class="node-data-value highlight-green" id="n2-vol">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Fichiers</span>
                            <span class="node-data-value" id="n2-files">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Tableaux</span>
                            <span class="node-data-value" id="n2-tables">—</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- NODE 3: REASONING ENGINE -->
            <div class="node" id="node3" data-default-x="800" data-default-y="50" style="width:300px;">
                <div class="port port-in" id="p3-in"></div>
                <div class="port port-out" id="p3-out"></div>
                <div class="node-header">
                    <span class="node-tag tag-llm">③ Expert LLM</span>
                    <span class="node-dot" id="dot3"></span>
                </div>
                <div class="node-body">
                    <div class="node-title-row">
                        <div class="node-icon icon-llm">LLM</div>
                        <div>
                            <div class="node-title">Reasoning Engine</div>
                            <div class="node-subtitle">Vérification des seuils</div>
                        </div>
                    </div>
                    <div class="node-data">
                        <div class="node-data-row">
                            <span class="node-data-label">Modèle</span>
                            <span class="node-data-value highlight-purple" id="n3-model">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Prompt</span>
                            <span class="node-data-value" id="n3-ptokens">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Completion</span>
                            <span class="node-data-value" id="n3-ctokens">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Total</span>
                            <span class="node-data-value highlight-amber" id="n3-tokens">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Latence</span>
                            <span class="node-data-value" id="n3-lat">—</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Température</span>
                            <span class="node-data-value" id="n3-temp">0.1</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- NODE 4: DISPATCH -->
            <div class="node" id="node4" data-default-x="480" data-default-y="320">
                <div class="port port-in" id="p4-in"></div>
                <div class="node-header">
                    <span class="node-tag tag-dispatch">④ Dispatcher</span>
                    <span class="node-dot" id="dot4"></span>
                </div>
                <div class="node-body">
                    <div class="node-title-row">
                        <div class="node-icon icon-out">OUT</div>
                        <div>
                            <div class="node-title">Sortie Telegram</div>
                            <div class="node-subtitle">Livraison du conseil</div>
                        </div>
                    </div>
                    <div class="node-data">
                        <div class="node-data-row">
                            <span class="node-data-label">Statut</span>
                            <span class="node-data-value highlight-cyan" id="n4-status">EN ATTENTE</span>
                        </div>
                        <div class="node-data-row">
                            <span class="node-data-label">Réponse</span>
                            <span class="node-data-value" id="n4-preview" style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">—</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- CANVAS ERROR BANNER -->
            <div class="canvas-error" id="canvas-error">
                <span id="canvas-error-text">Erreur…</span>
                <button class="canvas-error-close" onclick="document.getElementById('canvas-error').classList.remove('visible')">&times;</button>
            </div>

        </div>

        <!-- SIDEBAR LOGS -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-title-row">
                    <span class="sidebar-title">Journal Temps Réel</span>
                    <span class="sidebar-badge" id="log-badge">0 requêtes</span>
                </div>
                <div class="sidebar-controls">
                    <button class="filter-btn active" data-filter="all" onclick="setFilter('all',this)">Tout</button>
                    <button class="filter-btn" data-filter="SUCCESS" onclick="setFilter('SUCCESS',this)">✓ OK</button>
                    <button class="filter-btn" data-filter="ERROR" onclick="setFilter('ERROR',this)">✗ Erreurs</button>
                    <input type="text" class="search-input" id="log-search" placeholder="Rechercher…" oninput="renderLogs()">
                </div>
            </div>
            <div class="log-list" id="log-list">
                <!-- Logs rendered here -->
            </div>
        </div>
    </div>
</div>

<!-- ===== TEST MODAL ===== -->
<div class="modal-overlay" id="testModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">⚡ Injection dans le Pipeline</span>
            <button class="modal-close" onclick="closeModal('testModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Question de test</label>
                <input class="form-input" type="text" id="test-input" value="Qu'est ce qu'on fait pour les achats inférieur à 500 ?">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Modèle prioritaire</label>
                    <select class="form-select" id="test-model">
                        <!-- Populated by JS -->
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Température</label>
                    <input class="form-input" type="number" id="test-temp" value="0.1" min="0" max="2" step="0.1">
                </div>
            </div>
            <div class="response-area" id="test-response">
                <div class="resp-meta" id="test-resp-meta"></div>
                <div id="test-resp-body"></div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn modal-btn-secondary" onclick="closeModal('testModal')">Fermer</button>
            <button class="modal-btn modal-btn-primary" id="btn-fire" onclick="fireTest()">Lancer l'Analyse</button>
        </div>
    </div>
</div>

<!-- ===== CONFIG MODAL ===== -->
<div class="modal-overlay" id="configModal">
    <div class="modal" style="width:520px;">
        <div class="modal-header">
            <span class="modal-title">⚙ Configuration Système</span>
            <button class="modal-close" onclick="closeModal('configModal')">&times;</button>
        </div>
        <div class="modal-body" id="config-body">
            <!-- Populated by JS -->
        </div>
        <div class="modal-footer">
            <button class="modal-btn modal-btn-secondary" onclick="closeModal('configModal')">Fermer</button>
        </div>
    </div>
</div>

<!-- ===== HISTORY MODAL ===== -->
<div class="modal-overlay" id="historyModal">
    <div class="modal history-modal">
        <div class="modal-header">
            <span class="modal-title">📋 Historique Complet des Requêtes</span>
            <button class="modal-close" onclick="closeModal('historyModal')">&times;</button>
        </div>
        <div class="modal-body" style="flex:1;overflow:hidden;display:flex;flex-direction:column;gap:12px;">
            <div class="history-toolbar">
                <input type="text" class="history-search" id="history-search" placeholder="Rechercher par question, utilisateur, modèle…" oninput="renderHistoryTable()">
                <select class="form-select" id="history-filter" onchange="renderHistoryTable()" style="width:140px;padding:8px 32px 8px 12px;font-size:12px;">
                    <option value="all">Tous statuts</option>
                    <option value="SUCCESS">✓ Succès</option>
                    <option value="ERROR">✗ Erreurs</option>
                </select>
                <div class="history-alert" id="history-alert"></div>
                <span class="history-count" id="history-count">—</span>
            </div>
            <div class="history-table-wrap" id="history-table-wrap">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th class="col-id" onclick="sortHistory('id')">#<span class="sort-arrow" id="sort-id"></span></th>
                            <th onclick="sortHistory('timestamp')">Date / Heure<span class="sort-arrow" id="sort-timestamp"></span></th>
                            <th onclick="sortHistory('user_name')">Utilisateur<span class="sort-arrow" id="sort-user_name"></span></th>
                            <th onclick="sortHistory('question')">Question<span class="sort-arrow" id="sort-question"></span></th>
                            <th>Réponse</th>
                            <th onclick="sortHistory('model_used')">Modèle<span class="sort-arrow" id="sort-model_used"></span></th>
                            <th onclick="sortHistory('total_tokens')">Tokens<span class="sort-arrow" id="sort-total_tokens"></span></th>
                            <th onclick="sortHistory('latency_sec')">Latence<span class="sort-arrow" id="sort-latency_sec"></span></th>
                            <th onclick="sortHistory('status')">Statut<span class="sort-arrow" id="sort-status"></span></th>
                            <th style="width:50px;text-align:center;cursor:default;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="history-tbody">
                    </tbody>
                </table>
            </div>
            <div class="history-pagination" id="history-pagination"></div>
        </div>
        <div class="modal-footer">
            <button class="modal-btn modal-btn-secondary" onclick="closeModal('historyModal')">Fermer</button>
        </div>
    </div>
</div>

<script>
// ============================================================================
// STATE
// ============================================================================
let allLogs = [];
let currentFilter = 'all';
let expandedLogIds = new Set();  // Track expanded log cards across re-renders
let configData = null;

// ============================================================================
// CLOCK
// ============================================================================
function updateClock() {
    const now = new Date();
    document.getElementById('live-clock').textContent =
        now.toLocaleTimeString('fr-FR', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

// ============================================================================
// MODALS
// ============================================================================
function openModal(id) {
    document.getElementById(id).classList.add('visible');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('visible');
}

// ============================================================================
// DRAG & DROP SYSTEM
// ============================================================================
const nodes = document.querySelectorAll('.node');
let dragState = null;
const STORAGE_KEY = 'ameno_ct_node_positions';

function getDefaultPos(node) {
    return {
        x: parseInt(node.dataset.defaultX) || 40,
        y: parseInt(node.dataset.defaultY) || 40
    };
}

function loadPositions() {
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch(e) {}
    nodes.forEach(node => {
        const pos = saved[node.id] || getDefaultPos(node);
        node.style.left = pos.x + 'px';
        node.style.top = pos.y + 'px';
    });
}

function savePositions() {
    const positions = {};
    nodes.forEach(node => {
        positions[node.id] = {
            x: parseInt(node.style.left) || 0,
            y: parseInt(node.style.top) || 0
        };
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(positions));
}

function resetLayout() {
    localStorage.removeItem(STORAGE_KEY);
    nodes.forEach(node => {
        const pos = getDefaultPos(node);
        node.style.left = pos.x + 'px';
        node.style.top = pos.y + 'px';
    });
    updateWires();
}

nodes.forEach(node => {
    node.addEventListener('mousedown', (e) => {
        // Don't drag if clicking inside data/ports
        if (e.target.closest('.port')) return;
        e.preventDefault();
        const rect = node.getBoundingClientRect();
        dragState = {
            node: node,
            offsetX: e.clientX - rect.left,
            offsetY: e.clientY - rect.top
        };
        node.classList.add('dragging');
    });
});

document.addEventListener('mousemove', (e) => {
    if (!dragState) return;
    const canvas = document.getElementById('canvas');
    const canvasRect = canvas.getBoundingClientRect();
    let newX = e.clientX - canvasRect.left - dragState.offsetX;
    let newY = e.clientY - canvasRect.top - dragState.offsetY;
    // Clamp within canvas
    newX = Math.max(0, Math.min(newX, canvasRect.width - dragState.node.offsetWidth));
    newY = Math.max(0, Math.min(newY, canvasRect.height - dragState.node.offsetHeight));
    dragState.node.style.left = newX + 'px';
    dragState.node.style.top = newY + 'px';
    updateWires();
});

document.addEventListener('mouseup', () => {
    if (dragState) {
        dragState.node.classList.remove('dragging');
        dragState = null;
        savePositions();
    }
});

// ============================================================================
// SVG WIRE DRAWING
// ============================================================================
function updateWires() {
    const canvas = document.getElementById('canvas');
    const canvasRect = canvas.getBoundingClientRect();

    function getPortCenter(id) {
        const el = document.getElementById(id);
        if (!el) return { x: 0, y: 0 };
        const r = el.getBoundingClientRect();
        return {
            x: (r.left + r.width / 2) - canvasRect.left,
            y: (r.top + r.height / 2) - canvasRect.top
        };
    }

    function bezier(from, to) {
        const dx = Math.abs(to.x - from.x);
        const tension = Math.max(60, dx * 0.4);
        return `M ${from.x} ${from.y} C ${from.x + tension} ${from.y}, ${to.x - tension} ${to.y}, ${to.x} ${to.y}`;
    }

    // Wire from node3 to node4 needs special curved path (goes down)
    function bezierDown(from, to) {
        const dx = Math.abs(to.x - from.x);
        const dy = Math.abs(to.y - from.y);
        const tx = Math.max(80, dx * 0.5);
        const ty = Math.max(40, dy * 0.3);
        return `M ${from.x} ${from.y} C ${from.x + tx} ${from.y + ty}, ${to.x - tx} ${to.y - ty}, ${to.x} ${to.y}`;
    }

    const p1out = getPortCenter('p1-out');
    const p2in = getPortCenter('p2-in');
    const p2out = getPortCenter('p2-out');
    const p3in = getPortCenter('p3-in');
    const p3out = getPortCenter('p3-out');
    const p4in = getPortCenter('p4-in');

    document.getElementById('wire1').setAttribute('d', bezier(p1out, p2in));
    document.getElementById('wire2').setAttribute('d', bezier(p2out, p3in));
    document.getElementById('wire3').setAttribute('d', bezierDown(p3out, p4in));
}

// ============================================================================
// WORKFLOW ANIMATION STATE
// ============================================================================
function setWorkflowState(state, errorMsg) {
    const wires = ['wire1', 'wire2', 'wire3'].map(id => document.getElementById(id));
    const nodeDots = ['dot1', 'dot2', 'dot3', 'dot4'].map(id => document.getElementById(id));
    const nodeEls = ['node1', 'node2', 'node3', 'node4'].map(id => document.getElementById(id));

    // Reset
    wires.forEach(w => { w.className.baseVal = 'wire-path'; });
    nodeDots.forEach(d => { d.className = 'node-dot'; });
    nodeEls.forEach(n => {
        n.classList.remove('state-active', 'state-success', 'state-error');
    });

    if (state === 'running') {
        wires.forEach(w => w.classList.add('wire-animated'));
        nodeDots.forEach(d => d.classList.add('dot-active'));
        nodeEls.forEach(n => n.classList.add('state-active'));
        document.getElementById('n4-status').textContent = 'CALCUL EN COURS…';
        document.getElementById('n4-preview').textContent = '—';
        document.getElementById('canvas-error').classList.remove('visible');
    } else if (state === 'success') {
        wires.forEach(w => w.classList.add('wire-success'));
        nodeDots.forEach(d => d.classList.add('dot-success'));
        nodeEls.forEach(n => n.classList.add('state-success'));
        document.getElementById('n4-status').textContent = 'RÉPONSE LIVRÉE';
        document.getElementById('canvas-error').classList.remove('visible');
    } else if (state === 'error') {
        wires.forEach(w => w.classList.add('wire-error'));
        document.getElementById('node3').classList.add('state-error');
        document.getElementById('dot3').classList.add('dot-error');
        document.getElementById('n4-status').textContent = 'ÉCHEC';
        document.getElementById('canvas-error').classList.add('visible');
        document.getElementById('canvas-error-text').textContent = errorMsg || 'Erreur inconnue';
    }
}

// ============================================================================
// TEST PIPELINE
// ============================================================================
async function fireTest() {
    const q = document.getElementById('test-input').value;
    const model = document.getElementById('test-model').value;
    const temp = parseFloat(document.getElementById('test-temp').value) || 0.1;
    const respArea = document.getElementById('test-response');
    const btnFire = document.getElementById('btn-fire');

    respArea.classList.remove('visible');
    btnFire.textContent = '⏳ Traitement…';
    btnFire.disabled = true;
    closeModal('testModal');
    setWorkflowState('running');

    try {
        const res = await fetch('/api/run', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question: q, model: model, temperature: temp })
        });
        const data = await res.json();

        if (data.success) {
            setWorkflowState('success');
            document.getElementById('n4-preview').textContent = (data.response || '').substring(0, 60) + '…';
        } else {
            setWorkflowState('error', data.error);
        }

        // Show response in modal
        document.getElementById('test-resp-meta').textContent =
            `Modèle: ${(data.model||'').split('/').pop()} | Tokens: ${data.total_tokens} | Latence: ${data.latency}s | Statut: ${data.success ? 'OK' : 'ERREUR'}`;
        document.getElementById('test-resp-body').textContent = data.response || data.error || 'Pas de réponse';
        respArea.classList.add('visible');

        refreshTelemetry();
    } catch (e) {
        setWorkflowState('error', e.message);
    } finally {
        btnFire.textContent = 'Lancer l\'Analyse';
        btnFire.disabled = false;
    }
}

// ============================================================================
// LOG FILTERING
// ============================================================================
function setFilter(filter, btn) {
    currentFilter = filter;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderLogs();
}

function renderLogs() {
    const container = document.getElementById('log-list');
    const search = (document.getElementById('log-search').value || '').toLowerCase();

    let filtered = allLogs;
    if (currentFilter !== 'all') {
        filtered = filtered.filter(l => l.status === currentFilter);
    }
    if (search) {
        filtered = filtered.filter(l =>
            (l.question || '').toLowerCase().includes(search) ||
            (l.model_used || '').toLowerCase().includes(search) ||
            (l.user_name || '').toLowerCase().includes(search)
        );
    }

    container.innerHTML = '';
    filtered.forEach(l => {
        const isOk = l.status === 'SUCCESS';
        const logId = l.id || l.timestamp;  // Unique identifier
        const isExpanded = expandedLogIds.has(logId);
        const div = document.createElement('div');
        div.className = `log-card${isOk ? '' : ' log-error'}${isExpanded ? ' expanded' : ''}`;
        div.onclick = (e) => {
            // Prevent closing when scrolling inside the response area
            if (e.target.closest('.log-response')) return;
            const willExpand = !div.classList.contains('expanded');
            div.classList.toggle('expanded');
            if (willExpand) {
                expandedLogIds.add(logId);
            } else {
                expandedLogIds.delete(logId);
            }
        };
        div.innerHTML = `
            <div class="log-meta">
                <span>${(l.timestamp || '').split(' ')[1] || l.timestamp || '—'}</span>
                <span class="${isOk ? 'log-status-ok' : 'log-status-err'}">${l.status}</span>
            </div>
            <div class="log-question">${l.question || '—'}</div>
            <div class="log-footer">
                <span>${(l.model_used || '').split('/').pop()}</span>
                <span>${l.user_name || '—'}</span>
                <span>${l.latency_sec || 0}s · ${Number(l.total_tokens || 0).toLocaleString()}t</span>
            </div>
            <div class="log-response">${l.response || '—'}</div>
        `;
        container.appendChild(div);
    });

    document.getElementById('log-badge').textContent = `${filtered.length} requête${filtered.length > 1 ? 's' : ''}`;
}

// ============================================================================
// TELEMETRY POLLING
// ============================================================================
let lastSeenId = null;

async function refreshTelemetry() {
    try {
        const res = await fetch('/api/telemetry');
        const data = await res.json();

        // === Status pills ===
        const tgPill = document.getElementById('tg-pill');
        if (data.telegram.ok) {
            tgPill.className = 'status-pill pill-ok';
            tgPill.innerHTML = `<span class="pill-dot pill-dot-ok"></span> Telegram: ${data.telegram.user}`;
        } else {
            tgPill.className = 'status-pill pill-err';
            tgPill.innerHTML = '<span class="pill-dot pill-dot-err"></span> Telegram: OFF';
        }

        const orPill = document.getElementById('or-pill');
        if (data.openrouter.ok) {
            orPill.className = 'status-pill pill-ok';
            orPill.innerHTML = '<span class="pill-dot pill-dot-ok"></span> OpenRouter: OK';
        } else {
            orPill.className = 'status-pill pill-err';
            orPill.innerHTML = '<span class="pill-dot pill-dot-err"></span> OpenRouter: OFF';
        }

        // === Stats bar ===
        const stats = data.stats || {};
        document.getElementById('stat-total').textContent = stats.total_requests ?? '—';
        document.getElementById('stat-success').textContent =
            stats.success_rate != null ? stats.success_rate + '%' : '—';
        document.getElementById('stat-latency').textContent =
            stats.avg_latency != null ? stats.avg_latency + 's' : '—';
        document.getElementById('stat-tokens').textContent =
            stats.total_tokens != null ? Number(stats.total_tokens).toLocaleString() : '—';
        document.getElementById('stat-model').textContent =
            stats.top_model ? stats.top_model.split('/').pop() : '—';
        document.getElementById('stat-last').textContent =
            stats.last_activity || '—';

        // === Uptime ===
        if (data.uptime_sec != null) {
            const h = Math.floor(data.uptime_sec / 3600);
            const m = Math.floor((data.uptime_sec % 3600) / 60);
            document.getElementById('uptime-display').textContent =
                h > 0 ? `${h}h ${m}m` : `${m}m`;
        }

        // === Last run node data ===
        if (data.last_run) {
            const r = data.last_run;
            document.getElementById('n1-user').textContent = r.user_name || 'Anonyme';
            document.getElementById('n1-msg').textContent = r.question || '—';
            document.getElementById('n1-time').textContent = (r.timestamp || '').split(' ')[1] || '—';

            document.getElementById('n3-model').textContent = (r.model_used || '').split('/').pop();
            document.getElementById('n3-ptokens').textContent = `${Number(r.prompt_tokens || 0).toLocaleString()} t`;
            document.getElementById('n3-ctokens').textContent = `${Number(r.completion_tokens || 0).toLocaleString()} t`;
            document.getElementById('n3-tokens').textContent = `${Number(r.total_tokens || 0).toLocaleString()} t`;
            document.getElementById('n3-lat').textContent = `${r.latency_sec || 0}s`;

            const preview = (r.response || '').substring(0, 60);
            document.getElementById('n4-preview').textContent = preview ? preview + '…' : '—';

            // Detect new live runs from Telegram
            if (lastSeenId !== null && r.id !== lastSeenId) {
                setWorkflowState(r.status === 'SUCCESS' ? 'success' : 'error', r.error_details);
            }
            lastSeenId = r.id;
        }

        // === Docs info ===
        if (data.docs_info) {
            document.getElementById('n2-vol').textContent = data.docs_info.volume || '—';
            document.getElementById('n2-files').textContent = data.docs_info.files_count ?? '—';
            document.getElementById('n2-tables').textContent = data.docs_info.tables_count ?? '—';
        }

        // === Logs ===
        allLogs = data.logs || [];
        renderLogs();

        // === Config data (cache for modal) ===
        configData = data.config || null;

    } catch (e) {
        console.error('Telemetry error:', e);
    }
}

// ============================================================================
// CONFIG MODAL RENDER
// ============================================================================
function renderConfig() {
    const body = document.getElementById('config-body');
    if (!configData) {
        body.innerHTML = '<p style="color:var(--text-muted);font-size:12px;">Chargement…</p>';
        return;
    }
    const c = configData;
    const maskKey = (k) => k ? k.substring(0, 6) + '••••••••' : 'Non configurée';

    let modelsHtml = (c.models_pool || []).map(m =>
        `<span class="model-chip">${m.split('/').pop()}</span>`
    ).join('');

    body.innerHTML = `
        <div class="config-section">
            <div class="config-section-title">Connexions</div>
            <div class="config-row">
                <span class="config-key">Telegram Token</span>
                <span class="config-val ${c.telegram_ok ? 'ok' : 'err'}">${c.telegram_ok ? '✓ Connecté' : '✗ Déconnecté'}</span>
            </div>
            <div class="config-row">
                <span class="config-key">OpenRouter API Key</span>
                <span class="config-val ${c.openrouter_ok ? 'ok' : 'err'}">${maskKey(c.api_key_preview)}</span>
            </div>
        </div>
        <div class="config-section">
            <div class="config-section-title">Modèles LLM (Pool de Fallback)</div>
            <div style="padding:4px 0;">${modelsHtml || '<span style="color:var(--text-muted);font-size:11px;">Aucun modèle configuré</span>'}</div>
        </div>
        <div class="config-section">
            <div class="config-section-title">Base de Données</div>
            <div class="config-row">
                <span class="config-key">Chemin SQLite</span>
                <span class="config-val">${c.db_path || '—'}</span>
            </div>
            <div class="config-row">
                <span class="config-key">Entrées totales</span>
                <span class="config-val">${c.db_total_rows ?? '—'}</span>
            </div>
        </div>
        <div class="config-section">
            <div class="config-section-title">Référentiel Documentaire</div>
            <div class="config-row">
                <span class="config-key">Dossier</span>
                <span class="config-val">${c.docs_dir || '—'}</span>
            </div>
            <div class="config-row">
                <span class="config-key">Fichiers chargés</span>
                <span class="config-val">${c.docs_files ?? '—'}</span>
            </div>
            <div class="config-row">
                <span class="config-key">Volume texte</span>
                <span class="config-val">${c.docs_volume || '—'}</span>
            </div>
        </div>
    `;
}

// Re-render config when modal opens
const configModalEl = document.getElementById('configModal');
const obs = new MutationObserver(() => {
    if (configModalEl.classList.contains('visible')) renderConfig();
});
obs.observe(configModalEl, { attributes: true, attributeFilter: ['class'] });

// ============================================================================
// POPULATE MODEL SELECT
// ============================================================================
async function populateModels() {
    try {
        const res = await fetch('/api/telemetry');
        const data = await res.json();
        const select = document.getElementById('test-model');
        select.innerHTML = '';
        const models = (data.config && data.config.models_pool) || [];
        models.forEach((m, i) => {
            const opt = document.createElement('option');
            opt.value = m;
            opt.textContent = m.split('/').pop() + (i === 0 ? ' (prioritaire)' : '');
            select.appendChild(opt);
        });
        if (models.length === 0) {
            const opt = document.createElement('option');
            opt.value = '';
            opt.textContent = 'Aucun modèle';
            select.appendChild(opt);
        }
    } catch(e) { console.error(e); }
}

// ============================================================================
// HISTORY TABLE
// ============================================================================
let historyData = [];
let historySortKey = 'id';
let historySortDir = 'desc';
let historyPage = 1;
const HISTORY_PAGE_SIZE = 20;
let historyExpandedRows = new Set();

function openHistory() {
    openModal('historyModal');
    fetchHistory();
}

async function fetchHistory() {
    try {
        const res = await fetch('/api/history');
        const data = await res.json();
        historyData = data.rows || [];
        historyPage = 1;
        renderHistoryTable();
    } catch(e) {
        console.error('History fetch error:', e);
    }
}

function sortHistory(key) {
    if (historySortKey === key) {
        historySortDir = historySortDir === 'asc' ? 'desc' : 'asc';
    } else {
        historySortKey = key;
        historySortDir = key === 'id' ? 'desc' : 'asc';
    }
    renderHistoryTable();
}

function renderHistoryTable() {
    const search = (document.getElementById('history-search').value || '').toLowerCase();
    const statusFilter = document.getElementById('history-filter').value;

    // Filter
    let filtered = historyData;
    if (statusFilter !== 'all') {
        filtered = filtered.filter(r => r.status === statusFilter);
    }
    if (search) {
        filtered = filtered.filter(r =>
            (r.question || '').toLowerCase().includes(search) ||
            (r.user_name || '').toLowerCase().includes(search) ||
            (r.model_used || '').toLowerCase().includes(search) ||
            (r.response || '').toLowerCase().includes(search)
        );
    }

    // Sort
    filtered.sort((a, b) => {
        let va = a[historySortKey], vb = b[historySortKey];
        if (typeof va === 'number' && typeof vb === 'number') {
            return historySortDir === 'asc' ? va - vb : vb - va;
        }
        va = String(va || '').toLowerCase();
        vb = String(vb || '').toLowerCase();
        return historySortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
    });

    // Update sort arrows
    document.querySelectorAll('.sort-arrow').forEach(el => { el.textContent = ''; });
    const activeArrow = document.getElementById('sort-' + historySortKey);
    if (activeArrow) activeArrow.textContent = historySortDir === 'asc' ? ' ▲' : ' ▼';
    document.querySelectorAll('.history-table th').forEach(th => th.classList.remove('sorted'));
    if (activeArrow) activeArrow.closest('th').classList.add('sorted');

    // Paginate
    const totalPages = Math.max(1, Math.ceil(filtered.length / HISTORY_PAGE_SIZE));
    if (historyPage > totalPages) historyPage = totalPages;
    const start = (historyPage - 1) * HISTORY_PAGE_SIZE;
    const pageData = filtered.slice(start, start + HISTORY_PAGE_SIZE);

    // Count display
    document.getElementById('history-count').textContent = `${filtered.length} entrée${filtered.length > 1 ? 's' : ''}`;

    // Render rows
    const tbody = document.getElementById('history-tbody');
    tbody.innerHTML = '';
    pageData.forEach(r => {
        const isOk = r.status === 'SUCCESS';
        const isExpanded = historyExpandedRows.has(r.id);
        const tr = document.createElement('tr');
        tr.style.cursor = 'pointer';
        tr.onclick = () => {
            if (historyExpandedRows.has(r.id)) {
                historyExpandedRows.delete(r.id);
            } else {
                historyExpandedRows.add(r.id);
            }
            renderHistoryTable();
        };
        tr.innerHTML = `
            <td class="col-id">${r.id}</td>
            <td class="col-time">${r.timestamp || '—'}</td>
            <td class="col-user">${r.user_name || '—'}</td>
            <td class="col-question" title="${(r.question || '').replace(/"/g, '&quot;')}">${r.question || '—'}</td>
            <td class="col-response" title="Cliquez pour voir">${(r.response || '—').substring(0, 80)}${(r.response || '').length > 80 ? '…' : ''}</td>
            <td class="col-model">${(r.model_used || '').split('/').pop()}</td>
            <td class="col-tokens">${Number(r.total_tokens || 0).toLocaleString()}</td>
            <td class="col-latency">${r.latency_sec || 0}s</td>
            <td class="col-status"><span class="status-badge ${isOk ? 'ok' : 'err'}">${r.status}</span></td>
            <td style="text-align:center;" onclick="event.stopPropagation()">
                <button class="btn-delete-row" title="Supprimer l'enregistrement #${r.id}" onclick="deleteHistoryRow(${r.id}, event)">🗑</button>
            </td>
        `;
        tbody.appendChild(tr);

        // Detail expansion row
        if (isExpanded) {
            const detailTr = document.createElement('tr');
            detailTr.className = 'detail-row';
            detailTr.onclick = (e) => e.stopPropagation();
            detailTr.innerHTML = `
                <td colspan="10">
                    <div class="detail-content">
                        <div class="detail-col">
                            <div class="detail-label">Question complète</div>
                            <div class="detail-text">${r.question || '—'}</div>
                        </div>
                        <div class="detail-col" style="flex:2;">
                            <div class="detail-label">Réponse complète</div>
                            <div class="detail-text">${r.response || '—'}</div>
                            <button class="btn-delete-full" onclick="deleteHistoryRow(${r.id}, event)">🗑 Supprimer définitivement l'enregistrement #${r.id}</button>
                        </div>
                        ${r.error_details ? `<div class="detail-col"><div class="detail-label">Erreur</div><div class="detail-text" style="color:#fca5a5;">${r.error_details}</div></div>` : ''}
                    </div>
                </td>
            `;
            tbody.appendChild(detailTr);
        }
    });

    // Pagination controls
    const pagDiv = document.getElementById('history-pagination');
    pagDiv.innerHTML = '';
    if (totalPages > 1) {
        const prevBtn = document.createElement('button');
        prevBtn.className = 'page-btn';
        prevBtn.textContent = '← Préc.';
        prevBtn.disabled = historyPage <= 1;
        prevBtn.onclick = () => { historyPage--; renderHistoryTable(); };
        pagDiv.appendChild(prevBtn);

        // Page numbers (show up to 7)
        const showPages = [];
        for (let i = 1; i <= totalPages; i++) {
            if (i <= 3 || i > totalPages - 3 || Math.abs(i - historyPage) <= 1) {
                showPages.push(i);
            } else if (showPages[showPages.length - 1] !== '...') {
                showPages.push('...');
            }
        }
        showPages.forEach(p => {
            if (p === '...') {
                const span = document.createElement('span');
                span.className = 'page-info';
                span.textContent = '…';
                pagDiv.appendChild(span);
            } else {
                const btn = document.createElement('button');
                btn.className = `page-btn${p === historyPage ? ' active' : ''}`;
                btn.textContent = p;
                btn.onclick = () => { historyPage = p; renderHistoryTable(); };
                pagDiv.appendChild(btn);
            }
        });

        const nextBtn = document.createElement('button');
        nextBtn.className = 'page-btn';
        nextBtn.textContent = 'Suiv. →';
        nextBtn.disabled = historyPage >= totalPages;
        nextBtn.onclick = () => { historyPage++; renderHistoryTable(); };
        pagDiv.appendChild(nextBtn);
    }
}

// Delete history row
async function deleteHistoryRow(id, event) {
    if (event) event.stopPropagation();
    if (!confirm(`Supprimer définitivement l'enregistrement #${id} de l'historique ?`)) {
        return;
    }
    try {
        const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
            historyData = historyData.filter(r => r.id !== id);
            historyExpandedRows.delete(id);
            renderHistoryTable();
            showHistoryAlert(`✓ Enregistrement #${id} supprimé`);
            refreshTelemetry();
        } else {
            alert(`Erreur: ${data.error || 'Impossible de supprimer'}`);
        }
    } catch(e) {
        console.error('Delete error:', e);
        alert('Erreur réseau lors de la suppression');
    }
}

function showHistoryAlert(msg) {
    const el = document.getElementById('history-alert');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'inline-block';
    setTimeout(() => { el.style.display = 'none'; }, 3500);
}

// ============================================================================
// INIT
// ============================================================================
loadPositions();
setTimeout(updateWires, 60);
window.addEventListener('resize', updateWires);
setInterval(refreshTelemetry, 3000);
refreshTelemetry();
populateModels();
</script>
</body>
</html>
"""

# ==============================================================================
# ROUTES FLASK
# ==============================================================================

@app.route("/")
def index():
    return render_template_string(HTML_VIEW)


@app.route("/api/telemetry")
def telemetry():
    """Endpoint de télémétrie enrichi avec stats agrégées, infos docs et config."""

    # 1. Statut Telegram
    tg_ok, tg_user = False, "Hors-ligne"
    if TELEGRAM_TOKEN and "COLLEZ" not in TELEGRAM_TOKEN:
        try:
            r = requests.get(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/getMe", timeout=1.5)
            if r.status_code == 200:
                tg_ok = True
                tg_user = f"@{r.json()['result']['username']}"
        except Exception:
            pass

    # 2. Statut OpenRouter
    or_ok = False
    if OPENROUTER_API_KEY:
        try:
            r = requests.get(
                "https://openrouter.ai/api/v1/auth/key",
                headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
                timeout=1.5
            )
            if r.status_code == 200:
                or_ok = True
        except Exception:
            pass

    # 3. Lecture SQLite enrichie
    rows = []
    stats = {}
    db_total = 0
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()

        # Derniers logs
        cur.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 50")
        rows = [dict(r) for r in cur.fetchall()]

        # Stats agrégées
        cur.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as successes,
                ROUND(AVG(latency_sec), 2) as avg_lat,
                SUM(total_tokens) as sum_tokens,
                MAX(timestamp) as last_ts
            FROM audit_logs
        """)
        agg = dict(cur.fetchone())

        total = agg.get("total", 0) or 0
        successes = agg.get("successes", 0) or 0
        stats = {
            "total_requests": total,
            "success_rate": round((successes / total) * 100, 1) if total > 0 else 0,
            "avg_latency": agg.get("avg_lat") or 0,
            "total_tokens": agg.get("sum_tokens") or 0,
            "last_activity": (agg.get("last_ts") or "—").split(" ")[1] if agg.get("last_ts") else "—"
        }

        # Top modèle
        cur.execute("""
            SELECT model_used, COUNT(*) as cnt
            FROM audit_logs WHERE status = 'SUCCESS'
            GROUP BY model_used ORDER BY cnt DESC LIMIT 1
        """)
        top = cur.fetchone()
        stats["top_model"] = dict(top)["model_used"] if top else "—"

        # Total de lignes
        cur.execute("SELECT COUNT(*) as c FROM audit_logs")
        db_total = cur.fetchone()["c"]

        conn.close()
    except Exception as e:
        print(f"[DB READ WARNING] {e}")

    # 4. Infos documents
    docs_info = {"volume": "—", "files_count": 0, "tables_count": "—"}
    try:
        doc_text = getattr(agent, 'docs_texte', '')
        fichiers = [f for f in os.listdir(DOCS_DIR) if f.endswith(".docx") and not f.startswith("~$")]
        tables_count = doc_text.count("[TABLEAU SEUILS")
        docs_info = {
            "volume": f"{len(doc_text):,} car.".replace(",", " "),
            "files_count": len(fichiers),
            "tables_count": tables_count
        }
    except Exception:
        pass

    # 5. Config
    config_info = {
        "telegram_ok": tg_ok,
        "openrouter_ok": or_ok,
        "api_key_preview": OPENROUTER_API_KEY[:8] if OPENROUTER_API_KEY else "",
        "models_pool": FREE_MODELS_POOL,
        "db_path": DB_PATH,
        "db_total_rows": db_total,
        "docs_dir": DOCS_DIR,
        "docs_files": docs_info["files_count"],
        "docs_volume": docs_info["volume"]
    }

    # 6. Uptime
    uptime_sec = int(time.time() - SERVER_START_TIME)

    return jsonify({
        "telegram": {"ok": tg_ok, "user": tg_user},
        "openrouter": {"ok": or_ok},
        "last_run": rows[0] if rows else None,
        "logs": rows,
        "stats": stats,
        "docs_info": docs_info,
        "config": config_info,
        "uptime_sec": uptime_sec
    })


@app.route("/api/run", methods=["POST"])
def run_pipeline():
    """Exécution du pipeline avec paramètres optionnels depuis la console."""
    payload = request.get_json() or {}
    question = payload.get("question", "Test de validation")

    # Exécution de l'agent
    res = agent.repondre(question, user_name="Admin_Console")
    return jsonify(res)


@app.route("/api/history")
def history():
    """Retourne l'intégralité des logs pour le tableau historique."""
    rows = []
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 500")
        rows = [dict(r) for r in cur.fetchall()]
        conn.close()
    except Exception as e:
        print(f"[DB HISTORY WARNING] {e}")
    return jsonify({"rows": rows})


@app.route("/api/history/<int:row_id>", methods=["DELETE"])
def delete_history_row(row_id):
    """Supprime une ligne spécifique de l'historique d'audit."""
    try:
        conn = sqlite3.connect(DB_PATH, timeout=5.0)
        cur = conn.cursor()
        cur.execute("DELETE FROM audit_logs WHERE id = ?", (row_id,))
        conn.commit()
        affected = cur.rowcount
        conn.close()
        if affected > 0:
            return jsonify({"success": True, "deleted_id": row_id})
        else:
            return jsonify({"success": False, "error": "Enregistrement non trouvé"}), 404
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


# ==============================================================================
# MAIN
# ==============================================================================
if __name__ == "__main__":
    print("\n>>> AMENO CONTROL TOWER v2 DÉMARRÉ SUR : http://localhost:5000 <<<\n")
    app.run(host="0.0.0.0", port=5000, debug=False)