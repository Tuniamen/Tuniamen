# ==============================================================================
# FICHIER : agent_expert.py
# RÔLE    : Extraction des 30 pages Word en RAM, interrogation IA & audit SQLite.
# ==============================================================================

import os
import time
import sqlite3
import docx
from openai import OpenAI
from config import (
    OPENROUTER_API_KEY,
    FREE_MODELS_POOL,
    DOCS_DIR,
    DB_PATH,
    SIGNATURE_DISCLAIMER
)

# ------------------------------------------------------------------------------
# 1. BASE DE DONNÉES LOCALE (MODE CONCURRENT WAL)
# ------------------------------------------------------------------------------
def init_db():
    """
    Initialise la table d'audit et active le mode journal WAL (Write-Ahead Logging).
    Permet au Dashboard de lire les métriques en direct sans bloquer les écritures du Bot.
    """
    conn = sqlite3.connect(DB_PATH, timeout=20.0)
    cur = conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL;")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            user_name TEXT,
            question TEXT,
            response TEXT,
            model_used TEXT,
            prompt_tokens INTEGER,
            completion_tokens INTEGER,
            total_tokens INTEGER,
            latency_sec REAL,
            status TEXT,
            error_details TEXT
        )
    """)
    conn.commit()
    conn.close()

# Exécution systématique à l'importation
init_db()

def log_audit(user_name, question, response, model_used, p_tokens, c_tokens, t_tokens, latency, status, error=""):
    """Insère un enregistrement de télémétrie et de conversation dans SQLite."""
    conn = sqlite3.connect(DB_PATH, timeout=20.0)
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO audit_logs (
            user_name, question, response, model_used,
            prompt_tokens, completion_tokens, total_tokens, latency_sec, status, error_details
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_name, question, response, model_used, p_tokens, c_tokens, t_tokens, latency, status, error))
    conn.commit()
    conn.close()


# ------------------------------------------------------------------------------
# 2. LECTURE ET PARSING DU MANUEL WORD (PARAGRAPHES & TABLEAUX)
# ------------------------------------------------------------------------------
def extraire_texte_docx(chemin: str) -> str:
    """
    Transforme les paragraphes et reconstitue les tableaux avec séparateurs '|'
    pour préserver la cohérence des seuils chiffrés et des matrices de délégation.
    """
    doc = docx.Document(chemin)
    contenu = []

    for elem in doc.element.body:
        # Traitement des paragraphes standards
        if elem.tag.endswith('p'):
            p = docx.text.paragraph.Paragraph(elem, doc)
            if p.text.strip():
                contenu.append(p.text.strip())
        # Traitement des tableaux financiers
        elif elem.tag.endswith('tbl'):
            table = docx.table.Table(elem, doc)
            contenu.append("\n[TABLEAU SEUILS / DÉLÉGATIONS]")
            for row in table.rows:
                cells = [c.text.strip().replace("\n", " ") for c in row.cells]
                # Dédoublonnage des cellules fusionnées
                row_clean = []
                for val in cells:
                    if not row_clean or val != row_clean[-1]:
                        row_clean.append(val)
                contenu.append(" | ".join(row_clean))
            contenu.append("[FIN DU TABLEAU]\n")

    return "\n".join(contenu)


# ------------------------------------------------------------------------------
# 3. MOTEUR EXPERT DES PROCÉDURES D'ACHATS
# ------------------------------------------------------------------------------
class AgentAchats:
    def __init__(self):
        """Charge une fois pour toutes les procédures Word en mémoire RAM au démarrage."""
        if not os.path.exists(DOCS_DIR):
            os.makedirs(DOCS_DIR)

        fichiers = [f for f in os.listdir(DOCS_DIR) if f.endswith(".docx") and not f.startswith("~$")]
        if not fichiers:
            self.docs_texte = "AUCUN DOCUMENT DE PROCÉDURE TROUVÉ DANS LE DOSSIER /docs."
        else:
            morceaux = []
            for f in fichiers:
                chemin_complet = os.path.join(DOCS_DIR, f)
                morceaux.append(f"=== MANUEL : {f} ===\n" + extraire_texte_docx(chemin_complet))
            self.docs_texte = "\n\n".join(morceaux)

        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPENROUTER_API_KEY,
        )

    def repondre(self, question: str, user_name: str = "Acheteur") -> dict:
        """
        Interroge le LLM avec le document intégral et concatène la signature légale unique.
        """
        t_start = time.time()

        system_prompt = (
            "Tu es l'assistant et auditeur officiel des procédures d'achats de l'entreprise.\n"
            "Tu t'adresses directement aux acheteurs internes.\n"
            "Tu as sous les yeux l'INTÉGRALITÉ du manuel de procédures ci-dessous (textes et tableaux).\n\n"
            "DIRECTIVES DE RÉPONSE STRICTES :\n"
            "1. Sois clair, poli, professionnel et opérationnel.\n"
            "2. Pour toute question sur un montant ou seuil financier (ex: < 500), trouve la règle ou tranche exacte dans les tableaux.\n"
            "3. Indique clairement les obligations : formulaires requis, besoin ou non de devis, et personnes habilitées à valider.\n"
            "4. Si et seulement si le sujet n'est jamais traité dans le document, indique avec courtoisie que la procédure actuelle ne le prévoit pas.\n\n"
            f"=== MANUEL OFFICIEL DES PROCÉDURES ACHATS ===\n{self.docs_texte}"
        )

        try:
            # Appel API avec pool de repli automatique
            res = self.client.chat.completions.create(
                model=FREE_MODELS_POOL[0],
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": question}
                ],
                temperature=0.1,
                extra_body={"models": FREE_MODELS_POOL}
            )

            latency = round(time.time() - t_start, 2)
            reponse_brute = res.choices[0].message.content.strip()

            # Ajout systématique du disclaimer officiel importé depuis config
            reponse_finale = reponse_brute + SIGNATURE_DISCLAIMER

            # Métriques réelles
            model_used = getattr(res, "model", FREE_MODELS_POOL[0])
            usage = getattr(res, "usage", None)
            p_tokens = getattr(usage, "prompt_tokens", 0) if usage else 0
            c_tokens = getattr(usage, "completion_tokens", 0) if usage else 0
            t_tokens = getattr(usage, "total_tokens", 0) if usage else 0

            # Journalisation dans SQLite
            log_audit(user_name, question, reponse_finale, model_used, p_tokens, c_tokens, t_tokens, latency, "SUCCESS")

            return {
                "success": True,
                "response": reponse_finale,
                "model": model_used,
                "prompt_tokens": p_tokens,
                "completion_tokens": c_tokens,
                "total_tokens": t_tokens,
                "latency": latency,
                "error": ""
            }

        except Exception as e:
            latency = round(time.time() - t_start, 2)
            err_msg = str(e)

            reponse_erreur = (
                "Désolé, une anomalie temporaire empêche de consulter les procédures. "
                "Veuillez réessayer dans un instant."
                + SIGNATURE_DISCLAIMER
            )

            log_audit(user_name, question, "", "ERREUR", 0, 0, 0, latency, "ERROR", err_msg)

            return {
                "success": False,
                "response": reponse_erreur,
                "model": "ERREUR",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "latency": latency,
                "error": err_msg
            }