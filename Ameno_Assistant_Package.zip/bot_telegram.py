# ==============================================================================
# FICHIER : bot_telegram.py
# RÔLE    : Interface Telegram, filtrage immédiat et rendu HTML avec blockquote.
# ==============================================================================

from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from config import TELEGRAM_TOKEN, SIGNATURE_DISCLAIMER
from agent_expert import AgentAchats, log_audit

# ------------------------------------------------------------------------------
# 1. INITIALISATION DU SERVICE
# ------------------------------------------------------------------------------
agent = AgentAchats()

# Mots-clés de politesse interceptés localement en 0 ms sans consommation d'API
SALUTATIONS = {"hello", "bonjour", "salut", "hi", "coucou", "salem", "bonsoir", "aide"}


# ------------------------------------------------------------------------------
# 2. GESTIONNAIRES D'ÉVÉNEMENTS (HANDLERS)
# ------------------------------------------------------------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Message d'accueil lors de la commande /start."""
    prenom = update.effective_user.first_name or "Acheteur"
    texte_start = (
        f"Bonjour {prenom} !\n\n"
        "Je suis l'assistant officiel dédié aux procédures d'achats internes.\n"
        "Posez-moi directement votre question (ex: seuils de validation, devis, règles dérogatoires)."
        + SIGNATURE_DISCLAIMER
    )
    await update.message.reply_text(texte_start, parse_mode="HTML")

async def reception_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Traitement des messages entrants de l'acheteur."""
    question = update.message.text.strip()
    user_name = update.effective_user.full_name or update.effective_user.username or "Acheteur Telegram"

    # Cas 1 : Salutation simple interceptée en local
    if question.lower() in SALUTATIONS:
        reponse_accueil = (
            "Bonjour ! Comment puis-je vous aider concernant les procédures d'achats ?\n"
            "Exemple : <i>« Quelle est la règle pour un achat inférieur à 500 DT ? »</i>"
            + SIGNATURE_DISCLAIMER
        )
        log_audit(user_name, question, reponse_accueil, "FILTRE_LOCAL", 0, 0, 0, 0.01, "SUCCESS")
        await update.message.reply_text(reponse_accueil, parse_mode="HTML")
        return

    # Cas 2 : Vraie question métier déléguée à l'Agent
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)
    resultat = agent.repondre(question, user_name=user_name)

    # Envoi avec parse_mode="HTML" pour rendre le <blockquote> grisé/adouci
    try:
        await update.message.reply_text(resultat["response"], parse_mode="HTML")
    except Exception:
        # Repli de sécurité en texte brut si la réponse du LLM contenait des balises non fermées
        await update.message.reply_text(resultat["response"])


# ------------------------------------------------------------------------------
# 3. BOUCLE PRINCIPALE D'ÉCOUTE
# ------------------------------------------------------------------------------
def main():
    if not TELEGRAM_TOKEN or "COLLEZ" in TELEGRAM_TOKEN:
        print("[ERREUR CRITIQUE] TELEGRAM_TOKEN absent ou non configuré dans .env")
        return

    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, reception_message))

    print(">>> Agent Achats en ligne sur Telegram (Rendu HTML avec Blockquote actif).")
    app.run_polling()

if __name__ == "__main__":
    main()