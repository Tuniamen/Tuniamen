@echo off
cd /d "%~dp0"
call lancer_ameno.bat --stop
echo.
echo Fermeture dans 3 secondes...
timeout /t 3 >nul
