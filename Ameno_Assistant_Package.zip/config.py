#----------------------------------
# CONFIG ce fichier est utilisé pour configurer les paramètres de l'application: il charge les clés secrétes du fichier .env e
# et définit les paramètres de l'application ( le nom du modéle AI, le nom de la base de données, le port du serveur, etc.)
#----------------------------------


import os
from dotenv import load_dotenv

# ------------------------------------------------------------------------------
# 1. CHARGEMENT DE L'ENVIRONNEMENT ET DES CLÉS
# ------------------------------------------------------------------------------
load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")

# ------------------------------------------------------------------------------
# 2. PERSISTANCE ET DOSSIER DOCUMENTAIRE
# ------------------------------------------------------------------------------
DB_PATH = "assistant_history.db"
DOCS_DIR = "docs"

# ------------------------------------------------------------------------------
# 3. POOL DE MODÈLES GRATUITS OPENROUTER (3 MAXIMUM selon quotas OpenRouter)
# ------------------------------------------------------------------------------
FREE_MODELS_POOL = [
    "nvidia/nemotron-3-super-120b-a12b:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "cohere/north-mini-code:free"
]

# ------------------------------------------------------------------------------
# 4. SOURCE UNIQUE DE VÉRITÉ : DISCLAIMER OFFICIEL
# Utilisation de la balise HTML <blockquote> reconnue par Telegram pour afficher
# une bordure verticale et un texte adouci/grisé (couleur soft intégrée).
# ------------------------------------------------------------------------------
SIGNATURE_DISCLAIMER = (
    "\n\n<blockquote>"
    "⚠️ <i>Ceci est une réponse générée par une IA qui peut comporter des inexactitudes. "
    "Vous pouvez toujours vous référer à la procédure officielle disponible sur la plateforme "
    "de documentation du Groupe.</i>"
    "</blockquote>"
)
