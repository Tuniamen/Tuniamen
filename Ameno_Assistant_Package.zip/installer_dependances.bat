@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Ameno Assistant - Installation des dépendances

echo ================================================================================
echo           AMENO ASSISTANT - INSTALLATION DES COMPOSANTS REQUIS
echo ================================================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR CRITIQUE] Python n'est pas installé ou n'est pas dans le PATH.
    echo Veuillez installer Python 3.10 ou supérieur (https://www.python.org/)
    echo IMPORTANT : N'oubliez pas de cocher "Add Python to PATH" lors de l'installation.
    echo.
    pause
    exit /b 1
)

echo [1/2] Mise à niveau de pip...
python -m pip install --upgrade pip

echo.
echo [2/2] Installation des bibliothèques nécessaires depuis requirements.txt...
pip install -r requirements.txt

if %errorlevel% equ 0 (
    echo.
    echo ================================================================================
    echo [SUCCÈS] Toutes les dépendances sont installées avec succès !
    echo Vous pouvez maintenant double-cliquer sur "lancer_ameno.bat".
    echo ================================================================================
) else (
    echo.
    echo [ERREUR] Une erreur est survenue lors de l'installation des dépendances.
    echo Veuillez vérifier votre connexion Internet.
)

echo.
pause
